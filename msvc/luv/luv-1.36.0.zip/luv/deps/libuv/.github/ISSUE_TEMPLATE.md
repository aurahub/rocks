<!--
If you want to report a bug, you are in the right place!

If you need help or have a question, go here:
https://github.com/libuv/help/issues/new

If you are reporting a libuv test failure, please ensure that you are not
running the test as root.

Please include code that demonstrates the bug and keep it short and simple.
-->
* **Version**: <!-- libuv version -->
* **Platform**: <!-- `uname -a` (UNIX), or Windows version and machine type -->
